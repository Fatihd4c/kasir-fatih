<?php
session_start();

require 'functions.php';
cekLogin("admin");

$produk = query("SELECT * FROM produk");
$karyawan = query("SELECT * FROM admin");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <header>
    <h1>Dashboard Admin</h1>
    <?php if(isset($_SESSION["nama"])): ?>
      <p>Halo <?= htmlspecialchars($_SESSION["nama"]); ?></p>
    <?php endif; ?>
  </header>

  <nav>
    <a href="logout.php">Logout</a>
    <a href="data_produk.php">Data Produk</a>
    <a href="pelanggan.php">Data Pelanggan</a>
    <a href="transaksi.php">Transaksi</a>
    <a href="detail_penjualan.php">Detail Penjualan</a>
  </nav>

  <div class="container">
    <h2>Manajemen Produk</h2>
    <div class="user-nav">
      <a href="produk.php" class="button">Tambah Produk</a>
    </div>

    <table>
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Produk</th>
          <th>Harga</th>
          <th>Stock</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $i = 1; ?>
        <?php foreach ($produk as $row): ?>
        <tr>
          <td><?= $i ?></td>
          <td><?= $row["NamaProduk"]; ?></td>
          <td>Rp <?= number_format($row["Harga"], 0, ',', '.'); ?></td>
          <td><?= number_format($row["Stok"], 0, ',', '.'); ?></td>
          <td>
            <div class="action-buttons">
              <a href="ubah_produk.php?id=<?= $row['ProdukID']; ?>" class="button secondary">Ubah</a>
              <a href="hapus_produk.php?id=<?= $row['ProdukID']; ?>" class="button danger" onclick="return confirm('Yakin ingin menghapus?');">Hapus</a>
            </div>
          </td>
        </tr>
        <?php $i++; ?>
        <?php endforeach; ?>
      </tbody>
    </table>

    <h2>Manajemen Karyawan</h2>
    <div class="user-nav">
      <a href="register.php" class="button">Tambah Karyawan</a>
    </div>
    
    <table>
      <thead>
        <tr>
          <th>No</th>
          <th>NIK</th>
          <th>Nama Karyawan</th>
          <th>Alamat</th>
          <th>Level</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $i = 1; ?>
        <?php foreach ($karyawan as $row): ?>
        <tr>
          <td><?= $i ?></td>
          <td><?= $row["NIK"]?></td>
          <td><?= $row["Nama"]?></td>
          <td><?= $row["Alamat"]?></td>
          <td><?= $row["Level"]?></td>
          <td>
            <div class="action-buttons">
              <a href="ubah_karyawan.php?id=<?= $row['ID']; ?>" class="button secondary">Ubah</a>
              <a href="hapus_karyawan.php?id=<?= $row['ID']; ?>" class="button danger" onclick="return confirm('Yakin ingin menghapus?');">Hapus</a>
            </div>
          </td>
        </tr>
        <?php $i++; ?>
        <?php endforeach; ?>
      </tbody>
    </table>

  </div>
</body>
</html>

<?php
session_start();            // penting banget
require 'functions.php';

$success = '';
$errors = array();

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = []; // inisialisasi cart
}

// ambil data pelanggan & produk
$pelanggan = query('SELECT PelangganID, NamaPelanggan FROM pelanggan ORDER BY NamaPelanggan');
$produk    = query('SELECT ProdukID, NamaProduk, Harga, Stok FROM produk ORDER BY NamaProduk');

// --- proses form ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add_item') {
        $produk_id = (int)$_POST['produk_id'];
        $qty       = (int)$_POST['qty'];

        // ambil produk dari DB
        $p = query("SELECT ProdukID, NamaProduk, Harga FROM produk WHERE ProdukID=$produk_id");
        if ($p) {
            $p = $p[0];
            cart_add($p['ProdukID'], $p['NamaProduk'], $p['Harga'], $qty);
            $success = "Produk berhasil ditambahkan ke keranjang.";
        } else {
            $errors[] = "Produk tidak ditemukan.";
        }
    }

    if ($action === 'remove_item') {
        $produk_id = (int)$_POST['produk_id'];
        cart_remove($produk_id);
        $success = "Produk berhasil dihapus dari keranjang.";
    }

    if ($action === 'checkout') {
        if (empty($_POST['pelanggan_id'])) {
            $errors[] = "Pelanggan harus dipilih.";
        } else {
            $pelangganId = (int)$_POST['pelanggan_id'];
            $penjualanId = tambahTransaksi($pelangganId);
            if ($penjualanId) {
                $success = "Transaksi berhasil disimpan.";
            } else {
                $errors[] = "Gagal menyimpan transaksi.";
            }
        }
    }
}

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Transaksi Kasir</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Transaksi Kasir</h1>
  </header>

  <nav>
    <a href="kasir.php">Dashboard</a>
    <a href="data_produk.php">Data Produk</a>
    <a href="logout.php">Logout</a>
  </nav>

  <div class="container">
    <?php if ($success): ?>
      <div class="status status-success mb-3">
        <?= htmlspecialchars($success) ?>
      </div>
    <?php endif; ?>
    
    <?php if ($errors): ?>
      <div class="status status-danger mb-3">
        <ul>
          <?php foreach ($errors as $e): ?>
            <li><?= htmlspecialchars($e) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <div class="card mb-4">
      <div class="card-header">
        <h2>Tambah Item</h2>
      </div>
      <form method="post" class="grid grid-2">
        <input type="hidden" name="action" value="add_item">
        <div>
          <label for="produk_id">Produk</label>
          <select name="produk_id" id="produk_id" required>
            <option disabled selected>-- pilih produk --</option>
            <?php foreach ($produk as $p): ?>
            <option value="<?= $p['ProdukID'] ?>"><?= htmlspecialchars($p['NamaProduk']) ?> (Stok: <?= number_format($p['Stok'], 0, ',', '.'); ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label for="qty">Quantity</label>
          <input type="number" name="qty" id="qty" value="1" min="1" required>
        </div>
        <div style="grid-column: span 2;">
          <button type="submit" class="button">Tambah ke Keranjang</button>
        </div>
      </form>
    </div>

    <div class="card">
      <div class="card-header">
        <h2>Keranjang Belanja</h2>
      </div>
      
      <?php if (!cart_items()): ?>
        <p class="text-center">Keranjang kosong</p>
      <?php else: ?>
        <table>
          <thead>
            <tr>
              <th>No</th>
              <th>Produk</th>
              <th>Harga</th>
              <th>Qty</th>
              <th>Subtotal</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php $i = 1; ?>
            <?php foreach(cart_items() as $pid=>$row): ?>
              <tr>
                <td><?= $i ?></td>
                <td><?= htmlspecialchars($row['nama']) ?></td>
                <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
                <td><?= number_format($row['qty'], 0, ',', '.'); ?></td>
                <td>Rp <?= number_format($row['harga'] * $row['qty'], 0, ',', '.') ?></td>
                <td>
                  <form method="post" style="display:inline;">
                    <input type="hidden" name="action" value="remove_item">
                    <input type="hidden" name="produk_id" value="<?= $pid ?>">
                    <button type="submit" class="button" style="background: var(--danger-color);">Hapus</button>
                  </form>
                </td>
              </tr>
              <?php $i++; ?>
            <?php endforeach; ?>
          </tbody>
          <tfoot>
            <tr>
              <th colspan="4">TOTAL</th>
              <th colspan="2">Rp <?= number_format(cart_total(), 0, ',', '.') ?></th>
            </tr>
          </tfoot>
        </table>

        <div class="mt-4">
          <form method="post">
            <input type="hidden" name="action" value="checkout">
            <div class="grid grid-2">
              <div>
                <label for="tanggal">Tanggal</label>
                <input type="date" name="tanggal" id="tanggal" value="<?= date('Y-m-d') ?>" required>
              </div>
              <div>
                <label for="pelanggan_id">Pelanggan</label>
                <select name="pelanggan_id" id="pelanggan_id" required>
                  <option value="">-- pilih pelanggan --</option>
                  <?php foreach ($pelanggan as $pl): ?>
                    <option value="<?= $pl['PelangganID'] ?>"><?= htmlspecialchars($pl['NamaPelanggan']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div style="grid-column: span 2;">
                <button type="submit" name="submit" class="button" style="background: var(--success-color);">Simpan Transaksi</button>
              </div>
            </div>
          </form>
        </div>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>

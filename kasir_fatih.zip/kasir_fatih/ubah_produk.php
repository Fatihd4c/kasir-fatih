<?php
session_start();
require 'functions.php';
// Cek apakah user sudah login 
if( !isset($_SESSION["login"])){
    header("Location: index.php");
    exit;
}

// ...existing code...
$dataanggota = query("SELECT * FROM admin");
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id) {
    $produk = query("SELECT * FROM produk WHERE ProdukID = $id");
    if ($produk) {
        $produk = $produk[0];
    } else {
        $produk = ["NamaProduk"=>"", "Harga"=>"", "Stok"=>""];
    }
} else {
    $produk = ["NamaProduk"=>"", "Harga"=>"", "Stok"=>""];
}
if(isset($_POST["submit"])) {

    if(Produk_ubah($_POST) > 0 ){
        echo "<script>
            alert('Produk berhasil diubah!');
            
            document.location.href = 'data_produk.php';
        </script>";
    } else {
        echo "<script>
            alert('Produk gagal diubah!');
            document.location.href = 'produk.php';
        </script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Produk</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Ubah Produk</h1>
  </header>

  <nav>
    <a href="admin.php">Dashboard</a>
    <a href="data_produk.php">Data Produk</a>
    <a href="logout.php">Logout</a>
  </nav>

  <div class="container">
    <div class="card">
      <div class="card-header">
        <h2>Silahkan ubah data Produk</h2>
      </div>

      <form action="" method="post" enctype="multipart/form-data" class="grid grid-2" onsubmit="return formatHargaBeforeSubmit()">
        <input type="hidden" name="ID" value="<?= $produk["ProdukID"] ?>">
        
        <div>
          <label for="Nama">Nama Produk</label>
          <input type="text" name="Nama" id="Nama" autocomplete="off" required
          value="<?= htmlspecialchars($produk["NamaProduk"]) ?>">
        </div>

        <div>
          <label for="Harga">Harga</label>
          <input id="Harga" type="text" name="Harga" autocomplete="off" required
          value="<?= htmlspecialchars($produk["Harga"]) ?>">
        </div>

        <div>
          <label for="Stok">Stok</label>
          <input id="Stok" type="number" name="Stok" autocomplete="off" required min="0" step="1" max="9999999999"
          value="<?= htmlspecialchars($produk["Stok"]) ?>">
        </div>

        <div style="grid-column: span 2;">
          <button type="submit" name="submit" class="button">Update Data</button>
          <a href="data_produk.php" class="button" style="background: var(--secondary-color);">Kembali</a>
        </div>
      </form>
    </div>
  </div>

  <script>
    const input = document.getElementById("Harga");

    input.addEventListener("input", function(e) {
        let value = e.target.value;
        value = value.replace(/[^\d]/g, ""); // hapus semua kecuali angka
        if (value) {
            e.target.value = formatRupiah(value);
        } else {
            e.target.value = "";
        }
    });

    function formatRupiah(angka) {
        return "Rp " + angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    }

    function formatHargaBeforeSubmit() {
        const hargaInput = document.getElementById("Harga");
        // Hapus "Rp " dan semua titik (thousand separators)
        hargaInput.value = hargaInput.value.replace("Rp ", "").replace(/\./g, "");
        return true;
    }
  </script>
</body>
</html>

<?php
session_start();

require 'functions.php';
cekLogin(["admin", "karyawan"]);

$produk = query("SELECT * FROM produk");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Data Produk</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <header>
    <h1>Data Produk Toko</h1>
  </header>

  <nav>
    <a href="admin.php">Dashboard</a>
    <a href="produk.php">Tambah Produk</a>
    <a href="logout.php">Logout</a>
  </nav>

  <div class="container">
    <div class="card">
      <div class="card-header">
        <h2>Daftar Produk</h2>
      </div>
      
      <table>
        <thead>
          <tr>
            <th>No</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Stock</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $i = 1; ?>
          <?php foreach ($produk as $row): ?>
          <tr>
            <td><?= $i ?></td>
            <td><?= htmlspecialchars($row["NamaProduk"]); ?></td>
            <td>Rp <?= number_format($row["Harga"], 0, ',', '.'); ?></td>
            <td><?= number_format($row["Stok"], 0, ',', '.'); ?></td>
            <td>
              <div class="action-buttons">
                <a href="ubah_produk.php?id=<?= $row['ProdukID']; ?>" class="button" style="background: var(--warning-color);">Ubah</a>
                <a href="hapus_produk.php?id=<?= $row['ProdukID']; ?>" class="button" style="background: var(--danger-color);" onclick="return confirm('Yakin ingin menghapus?');">Hapus</a>
              </div>
            </td> 
          </tr>
          <?php $i++; ?>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>

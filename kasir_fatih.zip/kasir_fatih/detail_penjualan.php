<?php
session_start();

require 'functions.php';
cekLogin("admin");

// Query untuk mendapatkan data detail penjualan dengan join ke tabel penjualan dan produk
$detail_penjualan = query("
    SELECT dp.*, p.TanggalPenjualan, pr.NamaProduk, pl.NamaPelanggan
    FROM detail_penjualan dp
    LEFT JOIN penjualan p ON dp.PenjualanID = p.PenjualanID
    LEFT JOIN produk pr ON dp.ProdukID = pr.ProdukID
    LEFT JOIN pelanggan pl ON p.PelangganID = pl.PelangganID
    ORDER BY dp.DetailID DESC
");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Detail Penjualan</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <header>
    <h1>Detail Penjualan</h1>
    <?php if(isset($_SESSION["nama"])): ?>
      <p>Halo <?= htmlspecialchars($_SESSION["nama"]); ?></p>
    <?php endif; ?>
  </header>

  <nav>
    <a href="logout.php">Logout</a>
    <a href="admin.php">Dashboard</a>
    <a href="data_produk.php">Data Produk</a>
    <a href="pelanggan.php">Tambah Data Pelanggan</a>
    <a href="transaksi.php">Transaksi</a>
    
  </nav>

  <div class="container">
    <h2>Detail Penjualan</h2>
    <table>
      <thead>
        <tr>
          <th>No</th>
          <th>Detail ID</th>
          <th>Penjualan ID</th>
          <th>Tanggal</th>
          <th>Produk</th>
          <th>Jumlah Produk</th>
          <th>Subtotal</th>
          <th>Pelanggan</th>
        </tr>
      </thead>
      <tbody>
        <?php $i = 1; ?>
        <?php foreach ($detail_penjualan as $row): ?>
        <tr>
          <td><?= $i ?></td>
          <td><?= $row["DetailID"]; ?></td>
          <td><?= $row["PenjualanID"]; ?></td>
          <td><?= $row["TanggalPenjualan"]; ?></td>
          <td><?= $row["NamaProduk"]; ?></td>
          <td><?= number_format($row["JumlahProduk"], 0, ',', '.'); ?></td>
          <td>Rp <?= number_format($row["Subtotal"], 0, ',', '.'); ?></td>
          <td><?= $row["NamaPelanggan"]; ?></td>
        </tr>
        <?php $i++; ?>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</body>
</html>

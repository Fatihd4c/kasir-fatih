<?php
session_start();
require 'functions.php';
// Cek apakah user sudah login 
if( !isset($_SESSION["login"])){
    header("Location: index.php");
    exit;
}

$query = mysqli_query($conn, "SELECT MAX(nik) AS nik_terakhir FROM admin");
$data = mysqli_fetch_assoc($query);
$nik_terakhir = $data['nik_terakhir'];

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$karyawan = ($id > 0) ? query("SELECT * FROM admin WHERE ID = $id")[0] : null;

// // Kalau ada data, tambahkan 1, kalau belum ada mulai dari 20200801
// if ($nik_terakhir) {
//     $nik_baru = strval(intval($nik_terakhir) + 1);
// } else {
//     $nik_baru = "20200801"; // NIK awal
// }


$dataanggota = query("SELECT * FROM admin");
if(isset($_POST["submit"])) {

    if(ubah($_POST) > 0 ){
        echo "<script>
            alert('Data berhasil ubah!');
            
            document.location.href = 'admin.php';
        </script>";
    } else {
        echo "<script>
            alert('Data gagal ubah!');
            document.location.href = 'admin.php';
        </script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Karyawan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Ubah Karyawan</h1>
  </header>

  <nav>
    <a href="admin.php">Dashboard</a>
    <a href="data_produk.php">Data Produk</a>
    <a href="logout.php">Logout</a>
  </nav>

  <div class="container">
    <div class="card">
      <div class="card-header">
        <h2>Silahkan ubah data Karyawan</h2>
      </div>

      <form action="" method="post" enctype="multipart/form-data" class="grid grid-2">
        <input type="hidden" name="ID" value="<?= $karyawan['ID'] ?>">
        
        <div>
          <label for="NIK">NIK</label>
          <input type="text" name="NIK" id="NIK" value="<?= $karyawan["NIK"]?>" readonly>
        </div>

        <div>
          <label for="Nama">Nama</label>
          <input id="Nama" type="text" name="Nama" autocomplete="off" required
          value="<?= htmlspecialchars($karyawan["Nama"])?>">
        </div>

        <div>
          <label for="Alamat">Alamat</label>
          <input id="Alamat" type="text" name="Alamat" autocomplete="off" required
          value="<?= htmlspecialchars($karyawan["Alamat"])?>">
        </div>

        <div>
          <label for="Password">Password</label>
          <input id="Password" type="password" name="Password" autocomplete="off" required
          value="<?= htmlspecialchars($karyawan["Password"])?>">
        </div>

        <div style="grid-column: span 2;">
          <label>Level</label>
          <div class="radio-group">
            <label>
              <input type="radio" name="Level" value="admin" required
              <?= $karyawan['Level'] == 'admin' ? 'checked' : '' ?>> Admin
            </label>
            <label>
              <input type="radio" name="Level" value="karyawan" required
              <?= $karyawan['Level'] == 'karyawan' ? 'checked' : '' ?>> Karyawan
            </label>
          </div>
        </div>

        <div style="grid-column: span 2;">
          <button type="submit" name="submit" class="button">Update Data</button>
          <a href="admin.php" class="button" style="background: var(--secondary-color);">Kembali</a>
        </div>
      </form>
    </div>
  </div>
</body>
</html>

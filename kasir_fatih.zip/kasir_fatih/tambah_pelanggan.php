<?php
session_start();
require 'functions.php';
// Cek apakah user sudah login 
if( !isset($_SESSION["login"])){
    header("Location: index.php");
    exit;
}

if(isset($_POST["submit"])) {
    if(tambahPelanggan($_POST) > 0 ){
        echo "<script>
            alert('Pelanggan berhasil ditambahkan!');
            document.location.href = 'pelanggan.php';
        </script>";
    } else {
        echo "<script>
            alert('Pelanggan gagal ditambahkan!');
            document.location.href = 'pelanggan.php';
        </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pelanggan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Tambah Pelanggan</h1>
  </header>

  <nav>
    <a href="admin.php">Dashboard</a>
    <a href="pelanggan.php">Data Pelanggan</a>
    <a href="data_produk.php">Data Produk</a>
    <a href="logout.php">Logout</a>
  </nav>

  <div class="container">
    <div class="card">
      <div class="card-header">
        <h2>Silahkan isi data Pelanggan</h2>
      </div>

      <form action="" method="post" enctype="multipart/form-data" class="grid grid-2">
        <div>
          <label for="Nama">Nama Pelanggan</label>
          <input type="text" name="Nama" id="Nama" autocomplete="off" required>
        </div>

        <div>
          <label for="Alamat">Alamat</label>
          <input id="Alamat" type="text" name="Alamat" autocomplete="off" required>
        </div>

        <div>
          <label for="Nomer_Telepon">Nomor Telepon</label>
          <input id="Nomer_Telepon" type="text" name="Nomer_Telepon" autocomplete="off" required>
        </div>

        <div style="grid-column: span 2;">
          <button type="submit" name="submit" class="button">Kirim Data</button>
          <a href="admin.php" class="button" style="background: var(--secondary-color);">Kembali</a>
        </div>
      </form>
    </div>
  </div>
</body>
</html>

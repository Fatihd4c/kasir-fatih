<?php
session_start();

require 'functions.php';
cekLogin("karyawan");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasir Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Dashboard Kasir</h1>
    <?php if(isset($_SESSION["nama"])): ?>
      <p>Halo, <?= htmlspecialchars($_SESSION["nama"]); ?></p>
    <?php endif; ?>
  </header>

  <nav>
    <a href="logout.php">Logout</a>
    <a href="data_produk.php">Data Produk</a>
    <a href="transaksi.php">Transaksi</a>
  </nav>

  <div class="container">
    <h2>Selamat Datang di Sistem Kasir</h2>
    <p>Silakan pilih menu di atas untuk memulai transaksi atau mengelola data.</p>
    
    <div class="user-nav">
      <a href="transaksi.php" class="button">Mulai Transaksi</a>
      <a href="data_produk.php" class="button secondary">Lihat Produk</a>
    </div>
  </div>
</body>
</html>

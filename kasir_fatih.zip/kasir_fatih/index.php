<?php
session_start();
require 'functions.php';


// Cek session
if( isset($_SESSION["login"])){
    header("Location: admin.php");
    exit;
}else if ( isset($_SESSION["admin"])){
    header("Location: kasir.php?ID=" . $_SESSION["ID"]);
    exit;
}

// Proses login
if (isset($_POST["login"])) {
    $nik = $_POST["NIK"];
    $password = $_POST["Password"];

    $result = mysqli_query($conn, "SELECT * FROM admin WHERE NIK = '$nik'");

    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);

        //if (password_verify($password, $row["Password"])) {
            // Login berhasil
            $_SESSION["login"] = true;
            $_SESSION["Level"] = $row["Level"];
            $_SESSION['NIK'] = $row['NIK'];
            $_SESSION['nama'] = $row['Nama'];

            // Redirect sesuai level
            if ($row["Level"] === "admin") {
                header("Location: admin.php");
            } else {
                header("Location: kasir.php");
            }
            exit;
        //}
    }

    $error = true;
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>

</head>
<link rel="stylesheet" href="style.css">
<body>
  <div class="container" style="max-width: 400px; margin: 100px auto;">
    <div class="card">
      <div class="card-header">
        <h1 class="text-center">LOGIN!</h1>
      </div>
      
      <?php if (isset($error)) : ?>
        <div class="status status-danger mb-3">
          Nama atau password salah!
        </div>
      <?php endif; ?>

      <form action="" method="post">
        <div class="form-group">
          <label for="NIK">NIK</label>
          <input type="text" name="NIK" id="NIK" autocomplete="off" required>
        </div>
        <div class="form-group">
          <label for="Password">Password</label>
          <input type="password" name="Password" id="Password" autocomplete="off" required>
        </div>
        <button type="submit" name="login" class="button" style="width: 100%;">Login</button>
      </form>
    </div>
  </div>
</body>

</html>
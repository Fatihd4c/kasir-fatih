<?php
session_start();
require 'functions.php';
// Cek apakah user sudah login 
if( !isset($_SESSION["login"])){
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pelanggan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Data Pelanggan</h1>
  </header>

  <nav>
    <a href="admin.php">Dashboard</a>
    <a href="data_produk.php">Data Produk</a>
    <a href="logout.php">Logout</a>
    <a href="tambah_pelanggan.php">Tambah Pelanggan</a>
  </nav>

  <div class="container">
    <h2>Daftar Pelanggan</h2>
    <table>
      <thead>
        <tr>
          <th>Nama</th>
          <th>Alamat</th>
          <th>Nomor Telepon</th>
        </tr>
      </thead>
      <tbody>
        <?php
        // Query to fetch customer data from the pelanggan table
        $customers = query("SELECT * FROM pelanggan");
        foreach ($customers as $customer) {
            echo "<tr>
                    <td>{$customer['NamaPelanggan']}</td>
                    <td>{$customer['Alamat']}</td>
                    <td>{$customer['NomerTelepon']}</td>
                  </tr>";
        }
        ?>
      </tbody>
    </table>
</div>
</body>
</html>
